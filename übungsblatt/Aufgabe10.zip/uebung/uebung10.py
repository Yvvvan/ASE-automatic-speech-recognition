import ...


def test_model(datadir, hmm, model, parameters):
    pass

def get_args():
    parser = argparse.ArgumentParser()
    # get arguments from outside
    parser.add_argument('--sourcedatadir', default='./TIDIGITS-ASE', type=str, help='Dir saves the datasource information')
    parser.add_argument('--savedir', default='./trained', type=str, help='Dir to save trained model and results')
    args = parser.parse_args()
    return args

if __name__ == "__main__":

    # parse arguments
    # data directory, e.g., /media/public/TIDIGITS-ASE
    # call:
    # python uebung10.py <data/dir>
    # e.g., python uebung11.py /media/public/TIDIGITS-ASE
    args = get_args()
    print("Arguments:")
    [print(key, val) for key, val in vars(args).items()]

    datadir = args.sourcedatadir
    savedir = args.savedir
    # parameters for the feature extraction
    parameters = {'window_size': 25e-3,
        'hop_size': 10e-3,
        'feature_type': 'MFCC_D_DD',
        'n_filters': 40,
        'fbank_fmin': 0,
        'fbank_fmax': 8000,
        'num_ceps': 13,
        'left_context': 10,
        'right_context': 10}

    # default HMM
    hmm = HMM.HMM()

    # 1.) Test mit vorgegebenen Daten
    # die Zustandswahrscheinlichkeiten passend zum HMM aus UE6
    posteriors = np.load('data/TEST-WOMAN-BF-7O17O49A.npy')

    # Transkription für die vorgegebenen Wahrscheinlichkeiten
    words = hmm.posteriors_to_transcription(posteriors)
    print('Given posteriori OUT: {}'.format(words))            # OUT: [’SEVEN’, ’OH’, ’ONE’, ’SEVEN’, ’OH’, ’FOUR’, ’NINE’]

    # in Übung7 trainiertes DNN Model name
    model_name = 
    # Model Pfad
    model_dir = os.path.join(savedir, 'model', model_name + '.pkl')
    # Laden des DNNs
    model = torch.load(model_dir)

    # Beispiel wav File
    test_audio = './TIDIGITS-ASE/TEST/wav/TEST-WOMAN-BF-7O17O49A.wav'
    # TODO
    # Hier bitte den eigenen Erkenner laufen lassen und das Ergebnis vergleichen

    print('OUT: {}'.format(words))  # OUT: [’SEVEN’, ’OH’, ’ONE’, ’SEVEN’, ’OH’, ’FOUR’, ’NINE’]

    # test DNN
    wer = test_model(args.datadir, hmm, model, parameters)
    print('--' * 40)
    print("Total WER: {}".format(wer))
