# import...
# z.B.: import recognizer.feature_extraction as fe

def compute_features():
    audio_file = 'data/TEST-MAN-AH-3O33951A.wav'
    
    # TODO read in audio_file and call make_frames()

if __name__ == "__main__":
    compute_features()
