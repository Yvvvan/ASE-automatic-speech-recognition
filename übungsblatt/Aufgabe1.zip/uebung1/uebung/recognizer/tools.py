# import...

def sec_to_samples(x, sampling_rate):
    # TODO implement this method
    pass

def next_pow2(x):
    # TODO implement this method
    pass


def dft_window_size(x, sampling_rate):
    # TODO implement this method
    pass


def get_num_frames(signal_length_samples, window_size_samples, hop_size_samples):
    # TODO implement this method
    pass