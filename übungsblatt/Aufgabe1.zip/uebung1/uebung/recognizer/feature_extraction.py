# import...
# z.B.: import recognizer.tools as tools

def make_frames(audio_data, sampling_rate, window_size, hop_size):
    # TODO implement this method
    pass
